<?php
$popupMeta = array (
    'moduleMain' => 'AOS_Quotes',
    'varName' => 'AOS_Quotes',
    'orderBy' => 'aos_quotes.name',
    'whereClauses' => array (
  'name' => 'aos_quotes.name',
  'quote_key_c' => 'aos_quotes_cstm.quote_key_c',
  'billing_contact' => 'aos_quotes.billing_contact',
  'billing_account' => 'aos_quotes.billing_account',
  'total_amount' => 'aos_quotes.total_amount',
  'expiration' => 'aos_quotes.expiration',
  'stage' => 'aos_quotes.stage',
  'term' => 'aos_quotes.term',
  'assigned_user_id' => 'aos_quotes.assigned_user_id',
),
    'searchInputs' => array (
  0 => 'name',
  4 => 'quote_key_c',
  5 => 'billing_contact',
  6 => 'billing_account',
  7 => 'total_amount',
  8 => 'expiration',
  9 => 'stage',
  10 => 'term',
  11 => 'assigned_user_id',
),
    'searchdefs' => array (
  'quote_key_c' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_QUOTE_KEY',
    'width' => '10%',
    'name' => 'quote_key_c',
  ),
  'name' => 
  array (
    'name' => 'name',
    'width' => '10%',
  ),
  'billing_contact' => 
  array (
    'name' => 'billing_contact',
    'width' => '10%',
  ),
  'billing_account' => 
  array (
    'name' => 'billing_account',
    'width' => '10%',
  ),
  'total_amount' => 
  array (
    'name' => 'total_amount',
    'width' => '10%',
  ),
  'expiration' => 
  array (
    'name' => 'expiration',
    'width' => '10%',
  ),
  'stage' => 
  array (
    'name' => 'stage',
    'width' => '10%',
  ),
  'term' => 
  array (
    'name' => 'term',
    'width' => '10%',
  ),
  'assigned_user_id' => 
  array (
    'name' => 'assigned_user_id',
    'type' => 'enum',
    'label' => 'LBL_ASSIGNED_TO',
    'function' => 
    array (
      'name' => 'get_user_array',
      'params' => 
      array (
        0 => false,
      ),
    ),
    'width' => '10%',
  ),
),
);
