<?php 
 //WARNING: The contents of this file are auto-generated

 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/aos_products_contacts_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/opportunities_accounts_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/accounts_aos_products_1MetaData.php');


?>