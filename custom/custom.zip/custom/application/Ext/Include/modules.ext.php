<?php 
 //WARNING: The contents of this file are auto-generated

 
 //WARNING: The contents of this file are auto-generated
$beanList['tc_terms_conditions'] = 'tc_terms_conditions';
$beanFiles['tc_terms_conditions'] = 'modules/tc_terms_conditions/tc_terms_conditions.php';
$moduleList[] = 'tc_terms_conditions';


?>