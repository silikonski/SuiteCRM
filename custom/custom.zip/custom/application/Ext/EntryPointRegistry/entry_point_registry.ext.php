<?php 
 //WARNING: The contents of this file are auto-generated


$entry_point_registry['generatePdf'] = array(
    'file' => 'custom/modules/AOS_PDF_Templates/generatePdf.php',
    'auth' => true,
);
?>