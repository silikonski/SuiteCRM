<?php
 // created: 2020-10-30 08:55:33
$dictionary['AOS_Quotes']['fields']['quote_editor_c']['labelValue']='quote editor';

 ?>