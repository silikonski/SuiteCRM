<?php
 // created: 2021-01-03 17:10:23
$dictionary['AOS_Quotes']['fields']['expiration']['display_default']='+1 month';
$dictionary['AOS_Quotes']['fields']['expiration']['inline_edit']=true;
$dictionary['AOS_Quotes']['fields']['expiration']['merge_filter']='disabled';

 ?>