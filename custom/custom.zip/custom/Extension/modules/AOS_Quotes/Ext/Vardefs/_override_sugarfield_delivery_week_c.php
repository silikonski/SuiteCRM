<?php
 // created: 2020-11-08 17:53:58
$dictionary['AOS_Quotes']['fields']['delivery_week_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['delivery_week_c']['labelValue']='delivery week';

 ?>