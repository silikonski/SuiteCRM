<?php
 // created: 2021-01-21 10:02:06
$dictionary['AOS_Quotes']['fields']['tc_line_items']['merge_filter']='disabled';
$dictionary['AOS_Quotes']['fields']['tc_line_items']['reportable']=true;

 ?>