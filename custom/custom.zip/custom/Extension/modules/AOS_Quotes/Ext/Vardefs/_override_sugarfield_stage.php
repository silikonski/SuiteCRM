<?php
 // created: 2020-11-08 13:15:40
$dictionary['AOS_Quotes']['fields']['stage']['required']=false;
$dictionary['AOS_Quotes']['fields']['stage']['inline_edit']=true;
$dictionary['AOS_Quotes']['fields']['stage']['merge_filter']='disabled';

 ?>