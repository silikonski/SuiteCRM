<?php
 // created: 2021-07-08 16:42:32
$dictionary['AOS_Quotes']['fields']['deliverycw_c']['inline_edit']=1;

 ?>