<?php
 // created: 2021-07-08 16:42:32
$dictionary['AOS_Quotes']['fields']['quotenum_related_c']['inline_edit']=1;

 ?>