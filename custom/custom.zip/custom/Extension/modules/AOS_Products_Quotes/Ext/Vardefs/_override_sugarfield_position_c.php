<?php
 // created: 2021-07-09 20:51:01
$dictionary['AOS_Products_Quotes']['fields']['position_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['position_c']['labelValue']='position';

 ?>