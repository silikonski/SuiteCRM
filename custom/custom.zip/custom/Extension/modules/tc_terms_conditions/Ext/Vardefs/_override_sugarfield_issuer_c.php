<?php
 // created: 2021-07-08 16:42:32
$dictionary['tc_terms_conditions']['fields']['issuer_c']['inline_edit']=1;

 ?>