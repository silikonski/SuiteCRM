<?php
 // created: 2021-08-04 12:00:31
$dictionary['tc_terms_conditions']['fields']['position_term_c']['inline_edit']='1';
$dictionary['tc_terms_conditions']['fields']['position_term_c']['labelValue']='position term';

 ?>