<?php 
 // created: 2021-03-31 12:07:07
$mod_strings['LBL_ISSUER'] = 'Issuer';

?>
