<?php
 // created: 2021-10-16 07:05:11
$dictionary['User']['fields']['region_c']['inline_edit']='1';
$dictionary['User']['fields']['region_c']['labelValue']='region c';

 ?>