<?php
//auto-generated file DO NOT EDIT
$layout_defs['AOS_Invoices']['subpanel_setup']['aos_quotes_aos_invoices']['override_subpanel_name'] = 'AOS_Invoices_subpanel_aos_quotes_aos_invoices';
?>