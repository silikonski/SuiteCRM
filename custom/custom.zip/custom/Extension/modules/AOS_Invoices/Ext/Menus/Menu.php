<?php

 unset($module_menu[0]);