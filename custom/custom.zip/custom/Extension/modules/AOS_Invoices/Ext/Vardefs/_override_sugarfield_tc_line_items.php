<?php
 // created: 2021-01-20 06:43:36
$dictionary['AOS_Invoices']['fields']['tc_line_items']['merge_filter']='disabled';
$dictionary['AOS_Invoices']['fields']['tc_line_items']['reportable']=true;

 ?>