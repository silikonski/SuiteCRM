<?php
 // created: 2020-11-08 20:53:06
$dictionary['AOS_Invoices']['fields']['invnum_related_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['invnum_related_c']['options']='numeric_range_search_dom';
$dictionary['AOS_Invoices']['fields']['invnum_related_c']['labelValue']='Relative Invoice Number:';
$dictionary['AOS_Invoices']['fields']['invnum_related_c']['enable_range_search']='1';

 ?>