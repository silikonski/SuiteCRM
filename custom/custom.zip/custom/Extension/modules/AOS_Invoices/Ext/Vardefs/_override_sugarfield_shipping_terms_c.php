<?php
 // created: 2021-07-08 16:42:32
$dictionary['AOS_Invoices']['fields']['shipping_terms_c']['inline_edit']=1;

 ?>