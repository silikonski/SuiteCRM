<?php
 // created: 2020-11-08 21:49:57
$dictionary['AOS_Invoices']['fields']['company_selection_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['company_selection_c']['labelValue']='Invoice Issuer:';

 ?>