<?php
 // created: 2021-01-10 12:12:08
$dictionary['AOS_Invoices']['fields']['aos_quotes_id_c']['inline_edit']=1;

 ?>