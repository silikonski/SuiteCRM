<?php
 // created: 2021-01-10 12:12:08
$dictionary['AOS_Invoices']['fields']['inv_relatefield_quote_c']['inline_edit']='';
$dictionary['AOS_Invoices']['fields']['inv_relatefield_quote_c']['labelValue']='inv relatefield quote';

 ?>