<?php
 // created: 2020-11-08 22:06:13
$dictionary['AOS_Invoices']['fields']['payment_terms_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['payment_terms_c']['labelValue']='Payment Terms';

 ?>