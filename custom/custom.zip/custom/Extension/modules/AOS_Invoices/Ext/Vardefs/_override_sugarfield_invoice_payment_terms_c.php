<?php
 // created: 2021-07-08 16:42:32
$dictionary['AOS_Invoices']['fields']['invoice_payment_terms_c']['inline_edit']=1;

 ?>