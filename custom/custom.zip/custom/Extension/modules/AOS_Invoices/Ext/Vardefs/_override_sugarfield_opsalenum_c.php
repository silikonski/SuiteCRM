<?php
 // created: 2020-12-21 15:38:16
$dictionary['AOS_Invoices']['fields']['opsalenum_c']['inline_edit']='';
$dictionary['AOS_Invoices']['fields']['opsalenum_c']['labelValue']='Sales Order Number';

 ?>