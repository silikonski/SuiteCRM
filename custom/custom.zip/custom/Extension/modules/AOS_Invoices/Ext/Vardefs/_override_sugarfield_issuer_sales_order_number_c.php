<?php
 // created: 2020-12-12 10:43:40
$dictionary['AOS_Invoices']['fields']['issuer_sales_order_number_c']['inline_edit']='';
$dictionary['AOS_Invoices']['fields']['issuer_sales_order_number_c']['labelValue']='Issuer Sales Order';

 ?>