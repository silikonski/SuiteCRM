<?php
 // created: 2021-01-03 18:46:59
$dictionary['AOS_Invoices']['fields']['status']['required']=true;
$dictionary['AOS_Invoices']['fields']['status']['inline_edit']=true;
$dictionary['AOS_Invoices']['fields']['status']['merge_filter']='disabled';

 ?>