<?php
 // created: 2021-01-03 18:50:35
$dictionary['AOS_Invoices']['fields']['description']['inline_edit']=true;
$dictionary['AOS_Invoices']['fields']['description']['comments']='Full text of the note';
$dictionary['AOS_Invoices']['fields']['description']['merge_filter']='disabled';
$dictionary['AOS_Invoices']['fields']['description']['rows']='4';

 ?>