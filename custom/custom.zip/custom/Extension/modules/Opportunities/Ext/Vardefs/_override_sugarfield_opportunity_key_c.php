<?php
 // created: 2020-12-18 14:52:52
$dictionary['Opportunity']['fields']['opportunity_key_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['opportunity_key_c']['labelValue']='Opportunity Key';

 ?>