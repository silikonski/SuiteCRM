<?php
 // created: 2020-12-12 11:52:58
$dictionary['Opportunity']['fields']['sales_order_nomber_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['sales_order_nomber_c']['labelValue']='Opportunities Order Nomber';

 ?>