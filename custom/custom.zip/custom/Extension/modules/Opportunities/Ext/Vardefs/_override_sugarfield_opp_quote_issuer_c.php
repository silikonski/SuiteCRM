<?php
 // created: 2020-12-03 14:45:40
$dictionary['Opportunity']['fields']['opp_quote_issuer_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['opp_quote_issuer_c']['labelValue']='Quote Issuer';

 ?>