<?php
 // created: 2020-10-27 19:47:21
$dictionary['Opportunity']['fields']['test1_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['test1_c']['labelValue']='test1';

 ?>