<?php
 // created: 2020-10-26 06:02:41
$dictionary['Opportunity']['fields']['opportunity_name_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['opportunity_name_c']['labelValue']='Opportunity Name';

 ?>