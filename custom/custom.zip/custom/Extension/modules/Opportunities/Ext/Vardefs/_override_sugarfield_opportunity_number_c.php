<?php
 // created: 2020-12-18 14:52:23
$dictionary['Opportunity']['fields']['opportunity_number_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['opportunity_number_c']['labelValue']='Opportunity Number';

 ?>