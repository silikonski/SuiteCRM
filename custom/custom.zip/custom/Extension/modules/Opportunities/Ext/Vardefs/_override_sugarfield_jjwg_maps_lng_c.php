<?php
 // created: 2020-03-24 18:53:05
$dictionary['Opportunity']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>