<?php
 // created: 2021-10-07 06:23:14
$dictionary['SecurityGroup']['fields']['region_c']['inline_edit']='1';
$dictionary['SecurityGroup']['fields']['region_c']['labelValue']='region';

 ?>