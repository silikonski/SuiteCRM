<?php
// created: 2021-07-08 16:22:46
$dictionary["AOS_Quotes"]["fields"]["aos_quotes_am_projecttemplates_1"] = array (
  'name' => 'aos_quotes_am_projecttemplates_1',
  'type' => 'link',
  'relationship' => 'aos_quotes_am_projecttemplates_1',
  'source' => 'non-db',
  'module' => 'AM_ProjectTemplates',
  'bean_name' => 'AM_ProjectTemplates',
  'side' => 'right',
  'vname' => 'LBL_AOS_QUOTES_AM_PROJECTTEMPLATES_1_FROM_AM_PROJECTTEMPLATES_TITLE',
);
