<?php
// created: 2020-05-25 15:14:17
$dictionary["Opportunity"]["fields"]["opportunities_accounts_1"] = array (
  'name' => 'opportunities_accounts_1',
  'type' => 'link',
  'relationship' => 'opportunities_accounts_1',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'side' => 'right',
  'vname' => 'LBL_OPPORTUNITIES_ACCOUNTS_1_FROM_ACCOUNTS_TITLE',
);
