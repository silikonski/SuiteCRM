<?php
// created: 2021-07-08 16:22:46
$dictionary["AM_ProjectTemplates"]["fields"]["aos_quotes_am_projecttemplates_1"] = array (
  'name' => 'aos_quotes_am_projecttemplates_1',
  'type' => 'link',
  'relationship' => 'aos_quotes_am_projecttemplates_1',
  'source' => 'non-db',
  'module' => 'AOS_Quotes',
  'bean_name' => 'AOS_Quotes',
  'vname' => 'LBL_AOS_QUOTES_AM_PROJECTTEMPLATES_1_FROM_AOS_QUOTES_TITLE',
  'id_name' => 'aos_quotes_am_projecttemplates_1aos_quotes_ida',
);
$dictionary["AM_ProjectTemplates"]["fields"]["aos_quotes_am_projecttemplates_1_name"] = array (
  'name' => 'aos_quotes_am_projecttemplates_1_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_AOS_QUOTES_AM_PROJECTTEMPLATES_1_FROM_AOS_QUOTES_TITLE',
  'save' => true,
  'id_name' => 'aos_quotes_am_projecttemplates_1aos_quotes_ida',
  'link' => 'aos_quotes_am_projecttemplates_1',
  'table' => 'aos_quotes',
  'module' => 'AOS_Quotes',
  'rname' => 'name',
);
$dictionary["AM_ProjectTemplates"]["fields"]["aos_quotes_am_projecttemplates_1aos_quotes_ida"] = array (
  'name' => 'aos_quotes_am_projecttemplates_1aos_quotes_ida',
  'type' => 'link',
  'relationship' => 'aos_quotes_am_projecttemplates_1',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_AOS_QUOTES_AM_PROJECTTEMPLATES_1_FROM_AM_PROJECTTEMPLATES_TITLE',
);
