<?php
// created: 2022-02-04 18:19:21
$dictionary["AOS_Quotes"]["fields"]["aos_quotes_contacts_1"] = array (
  'name' => 'aos_quotes_contacts_1',
  'type' => 'link',
  'relationship' => 'aos_quotes_contacts_1',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'side' => 'right',
  'vname' => 'LBL_AOS_QUOTES_CONTACTS_1_FROM_CONTACTS_TITLE',
);
