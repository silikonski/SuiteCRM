<?php
// created: 2020-05-26 14:20:03
$dictionary["AOS_Products"]["fields"]["aos_products_contacts_1"] = array (
  'name' => 'aos_products_contacts_1',
  'type' => 'link',
  'relationship' => 'aos_products_contacts_1',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'side' => 'right',
  'vname' => 'LBL_AOS_PRODUCTS_CONTACTS_1_FROM_CONTACTS_TITLE',
);
