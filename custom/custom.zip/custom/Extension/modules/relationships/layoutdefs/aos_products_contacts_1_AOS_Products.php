<?php
 // created: 2020-05-26 14:20:03
$layout_defs["AOS_Products"]["subpanel_setup"]['aos_products_contacts_1'] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_AOS_PRODUCTS_CONTACTS_1_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'aos_products_contacts_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
