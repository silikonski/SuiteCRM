<?php
 // created: 2022-02-04 18:19:21
$layout_defs["AOS_Quotes"]["subpanel_setup"]['aos_quotes_contacts_1'] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_AOS_QUOTES_CONTACTS_1_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'aos_quotes_contacts_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
