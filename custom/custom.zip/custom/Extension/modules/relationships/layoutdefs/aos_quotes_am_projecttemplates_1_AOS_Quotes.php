<?php
 // created: 2021-07-08 16:22:46
$layout_defs["AOS_Quotes"]["subpanel_setup"]['aos_quotes_am_projecttemplates_1'] = array (
  'order' => 100,
  'module' => 'AM_ProjectTemplates',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_AOS_QUOTES_AM_PROJECTTEMPLATES_1_FROM_AM_PROJECTTEMPLATES_TITLE',
  'get_subpanel_data' => 'aos_quotes_am_projecttemplates_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
