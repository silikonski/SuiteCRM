<?php
 // created: 2020-05-10 19:11:03
$dictionary['Account']['fields']['industry_roto_c']['inline_edit']='1';
$dictionary['Account']['fields']['industry_roto_c']['labelValue']='Industry';

 ?>