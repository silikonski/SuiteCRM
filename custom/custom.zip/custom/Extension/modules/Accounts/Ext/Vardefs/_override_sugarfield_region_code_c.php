<?php
 // created: 2020-12-03 12:40:52
$dictionary['Account']['fields']['region_code_c']['inline_edit']='1';
$dictionary['Account']['fields']['region_code_c']['labelValue']='Region Code:';

 ?>