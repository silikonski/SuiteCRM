<?php
 // created: 2020-10-25 16:04:13
$dictionary['Account']['fields']['process_c']['inline_edit']='1';
$dictionary['Account']['fields']['process_c']['labelValue']='Process';

 ?>