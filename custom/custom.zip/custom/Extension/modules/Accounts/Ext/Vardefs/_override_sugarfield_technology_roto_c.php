<?php
 // created: 2020-10-21 19:14:07
$dictionary['Account']['fields']['technology_roto_c']['inline_edit']='1';
$dictionary['Account']['fields']['technology_roto_c']['labelValue']='Technology';

 ?>