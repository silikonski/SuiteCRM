<?php
 // created: 2020-11-13 09:01:42
$dictionary['Account']['fields']['vat_number_c']['inline_edit']='1';
$dictionary['Account']['fields']['vat_number_c']['labelValue']='VAT Number';

 ?>