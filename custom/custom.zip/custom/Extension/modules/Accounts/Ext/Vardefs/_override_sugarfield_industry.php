<?php
 // created: 2020-11-11 13:36:26
$dictionary['Account']['fields']['industry']['len']=100;
$dictionary['Account']['fields']['industry']['inline_edit']=true;
$dictionary['Account']['fields']['industry']['comments']='The company belongs in this industry';
$dictionary['Account']['fields']['industry']['merge_filter']='disabled';

 ?>