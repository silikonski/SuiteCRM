<?php
//auto-generated file DO NOT EDIT
$layout_defs['Accounts']['subpanel_setup']['opportunities_accounts_1']['override_subpanel_name'] = 'Account_subpanel_opportunities_accounts_1';
?>