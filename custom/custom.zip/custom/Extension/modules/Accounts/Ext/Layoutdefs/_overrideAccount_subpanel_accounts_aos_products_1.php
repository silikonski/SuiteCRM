<?php
//auto-generated file DO NOT EDIT
$layout_defs['Accounts']['subpanel_setup']['accounts_aos_products_1']['override_subpanel_name'] = 'Account_subpanel_accounts_aos_products_1';
?>