<?php
 // created: 2020-10-27 18:12:05
$dictionary['AOS_Products']['fields']['machine_type_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['machine_type_c']['labelValue']='Machine Type';

 ?>