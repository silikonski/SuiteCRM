<?php
 // created: 2020-11-11 16:04:28
$dictionary['AOS_Products']['fields']['product_type_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['product_type_c']['labelValue']='product type';

 ?>