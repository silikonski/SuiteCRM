<?php
 // created: 2020-11-11 16:08:29
$dictionary['AOS_Products']['fields']['product_subtype_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['product_subtype_c']['labelValue']='Product Subtype';

 ?>