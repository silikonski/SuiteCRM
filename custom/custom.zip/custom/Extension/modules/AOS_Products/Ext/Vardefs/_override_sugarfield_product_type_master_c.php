<?php
 // created: 2020-11-11 15:40:42
$dictionary['AOS_Products']['fields']['product_type_master_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['product_type_master_c']['labelValue']='product type master';

 ?>