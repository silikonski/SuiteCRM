<?php
 // created: 2020-11-11 16:15:01
$dictionary['AOS_Products']['fields']['customs_code_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['customs_code_c']['labelValue']='HS Code';

 ?>