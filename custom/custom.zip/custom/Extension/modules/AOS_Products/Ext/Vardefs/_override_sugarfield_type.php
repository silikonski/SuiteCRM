<?php
 // created: 2020-11-11 16:17:18
$dictionary['AOS_Products']['fields']['type']['default']='';
$dictionary['AOS_Products']['fields']['type']['required']=true;

 ?>