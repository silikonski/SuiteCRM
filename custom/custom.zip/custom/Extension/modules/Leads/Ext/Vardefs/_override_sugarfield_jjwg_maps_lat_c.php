<?php
 // created: 2020-03-24 18:53:05
$dictionary['Lead']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>