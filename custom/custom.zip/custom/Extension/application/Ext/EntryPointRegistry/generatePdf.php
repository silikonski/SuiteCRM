<?php
$entry_point_registry['generatePdf'] = array(
    'file' => 'custom/modules/AOS_PDF_Templates/generatePdf.php',
    'auth' => true,
);