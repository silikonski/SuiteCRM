<?php 
$app_list_strings['invoice_status_dom'] = array (
  '' => '',
  'Paid' => 'Paid',
  'Unpaid' => 'Unpaid',
  'Cancelled' => 'Cancelled',
);$app_list_strings['company_selection'] = array (
  '' => '',
  'RGAT' => 'Rotografix AT',
  'RGRS' => 'Rotografix RS',
  'GGBG' => 'GlobalGraphics BG',
  'EXT' => 'Supplier Quote',
);$app_list_strings['quote_stage_dom'] = array (
  'Draft' => 'Draft',
  'Negotiation' => 'Negotiation',
  'Delivered' => 'Delivered',
  'On Hold' => 'On Hold',
  'Confirmed' => 'Confirmed',
  'Closed Accepted' => 'Closed Accepted',
  'Closed Lost' => 'Closed Lost',
  'Closed Dead' => 'Closed Dead',
);$app_list_strings['quote_term_dom'] = array (
  '' => '',
  'PIA' => 'Payment in advance',
  'NET15' => 'NET 15',
  'NET30' => 'NET 30',
  'NET60' => 'NET 60',
);