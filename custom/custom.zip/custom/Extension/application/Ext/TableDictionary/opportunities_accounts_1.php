<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/opportunities_accounts_1MetaData.php');

?>