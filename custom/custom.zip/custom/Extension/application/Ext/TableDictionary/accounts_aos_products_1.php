<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/accounts_aos_products_1MetaData.php');

?>