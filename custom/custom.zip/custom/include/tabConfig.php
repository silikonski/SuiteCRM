<?php
// created: 2020-05-26 14:46:39
$GLOBALS['tabStructure'] = array (
  'LBL_TABGROUP_SALES' => 
  array (
    'label' => 'LBL_TABGROUP_SALES',
    'modules' => 
    array (
      0 => 'Home',
      1 => 'Accounts',
      2 => 'Contacts',
      3 => 'Opportunities',
      4 => 'Leads',
    ),
  ),
  'LBL_TABGROUP_MARKETING' => 
  array (
    'label' => 'LBL_TABGROUP_MARKETING',
    'modules' => 
    array (
      0 => 'Home',
      1 => 'Accounts',
      2 => 'Contacts',
      3 => 'Leads',
      4 => 'Campaigns',
      5 => 'Prospects',
      6 => 'ProspectLists',
    ),
  ),
  'LBL_TABGROUP_SUPPORT' => 
  array (
    'label' => 'LBL_TABGROUP_SUPPORT',
    'modules' => 
    array (
      0 => 'Home',
      1 => 'Accounts',
      2 => 'Contacts',
      3 => 'Cases',
      4 => 'Bugs',
    ),
  ),
  'LBL_TABGROUP_ACTIVITIES' => 
  array (
    'label' => 'LBL_TABGROUP_ACTIVITIES',
    'modules' => 
    array (
      0 => 'Home',
      1 => 'Calendar',
      2 => 'AOS_Products',
      3 => 'Calls',
      4 => 'Meetings',
      5 => 'Emails',
      6 => 'Tasks',
      7 => 'Notes',
    ),
  ),
  'LBL_GROUPTAB4_1590503457' => 
  array (
    'label' => 'LBL_GROUPTAB4_1590503457',
    'modules' => 
    array (
      0 => 'AOS_Product_Categories',
      1 => 'AOS_Products',
      2 => 'AOS_Invoices',
      3 => 'AOS_Quotes',
    ),
  ),
);