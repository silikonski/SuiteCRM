<?php
$app_strings['LBL_GROUPTAB4_1590503457'] = 'Inventar';
$GLOBALS['app_list_strings']['sales_stage_dom']=array (
  'Prospecting' => 'Prospecting',
  'Qualification' => 'Qualification',
  'Proposal/Price Quote' => 'Proposal/Price Quote',
  'Negotiation/Review' => 'Negotiation/Review',
  'Closed Won' => 'Closed Won',
  'Closed Lost' => 'Closed Lost',
);

$GLOBALS['app_list_strings']['region_code_list']=array (
  '' => '',
  'Other' => '90',
  'RS_BA_ME_MK' => '70',
  'HR_SI' => '60',
  'BG' => '50',
  'AT' => '40',
  'BNB' => '4',
);
$GLOBALS['app_list_strings']['process_roto_list']=array (
  'Sheet_MJ_B2' => 'Sheet ≤ B2',
  'Sheet_V_B2' => 'Sheet > B2',
  'Web_MJ_580' => 'Web ≤ 580',
  'Web_V_580' => 'Web > 580',
  'Semi_Rotary' => 'Semi-rotary',
);
$GLOBALS['app_list_strings']['technology_roto_list']=array (
  'Other' => 'Other',
  'Dry_Offset' => 'Dry Offset',
  'Flexo_Printing' => 'Flexo Printing',
  'Rotogravure' => 'Rotogravure',
  'Rotary_Screen' => 'Rotary Screen',
  'Flat_Screen' => 'Flat Screen',
  'Hot_Foil' => 'Hot Foil',
  'Varnish' => 'Varnish',
  'Wet_Offset' => 'Wet Offset',
  'Lamination' => 'Lamination',
  'Digital' => 'Digital',
  'Cold_and_Heatset' => 'Cold and Heatset',
  'Waterless_Offset' => 'Waterless Offset',
  'Flexo_PrePress' => 'Flexo Pre-Press',
  'Offset_PrePress' => 'Offset Pre-Press',
);
$GLOBALS['app_list_strings']['machine_type_list']=array (
  '' => '',
  'sheet_fed_printing' => 'Sheet-fed Printing',
  'sheet_fed_converting' => 'Sheet-fed Converting',
  'web_fed_printing_VOD520mm' => 'Web-fed printing (>520 mm)',
  'web_fed_converting_VOD520mm' => 'Web-fed converting (>520 mm)',
  'web_fed_printing_MOD520mm' => 'Web-fed printing (',
  'web_fed_converting_MOD520mm' => 'Web-fed converting (',
);

$GLOBALS['app_list_strings']['machine_type_list']=array (
  '' => '',
  'sheet_fed_printing' => 'Sheet-fed Printing',
  'sheet_fed_converting' => 'Sheet-fed Converting',
);
$GLOBALS['app_list_strings']['sellable_list']=array (
  'no' => 'No',
  'yes' => 'Yes',
);
$GLOBALS['app_list_strings']['machine_type_roto_list']=array (
  'test' => 'test',
  'test1' => 'test1',
);
$GLOBALS['app_list_strings']['company_select_list_list']=array (
  '' => '',
  'RGAT' => 'Rotografix GmbH',
  'RGRS' => 'Rotografix d.o.o.',
  'GGBG' => 'GlobalGraphics o.o.d.',
);
$GLOBALS['app_list_strings']['machine_type_0']=array (
  '' => '',
  'sheet_fed_printing' => 'Sheet-fed Printing',
);
$GLOBALS['app_list_strings']['quote_stage_dom']=array (
  'Draft' => 'Draft',
  'Negotiation' => 'Negotiation',
  'Delivered' => 'Delivered',
  'On Hold' => 'On Hold',
  'Confirmed' => 'Confirmed',
  'Closed Accepted' => 'Closed Accepted',
  'Closed Lost' => 'Closed Lost',
  'Closed Dead' => 'Closed Dead',
);
$GLOBALS['app_list_strings']['quote_term_dom']=array (
  '' => '',
  'PIA' => 'Payment in advance',
  'NET15' => 'NET 15',
  'NET30' => 'NET 30',
  'NET60' => 'NET 60',
);
$GLOBALS['app_list_strings']['company_selection']=array (
  '' => '',
  'RGAT' => 'Rotografix AT',
  'RGRS' => 'Rotografix RS',
  'GGBG' => 'GlobalGraphics BG',
  'EXT' => 'Supplier Quote',
);

$GLOBALS['app_list_strings']['industry_dom']=array (
  'Other' => 'Other',
  'Label' => 'Label',
  'Books' => 'Books',
  'Flexible_Packaging' => 'Flexible Packaging',
  'Cardboard_Packaging' => 'Cardboard Packaging',
  'Corrugated' => 'Corrugated',
  'Security' => 'Security',
  'Coating' => 'Coating',
  'Machine_Production' => 'Machine Production',
  'Spare_Parts' => 'Spare Parts',
  'Consumables' => 'Consumables',
  'Second_hand_Equipment' => 'Second-hand Equipment',
);

$GLOBALS['app_list_strings']['account_type_dom']=array (
  '' => '',
  'Customer' => 'Customer',
  'Supplier' => 'Supplier',
  'Competitor' => 'Distributor',
  'Other' => 'Other',
);
$GLOBALS['app_list_strings']['products_list']=array (
);
$GLOBALS['app_list_strings']['product_subtype_list']=array (
  'UK_ONE' => 'UK1',
  'UK_TWO' => 'UK2',
  'US_ONE' => 'US1',
  'US_TWO' => 'US2',
);
$GLOBALS['app_list_strings']['product_type_dom']=array (
  '' => '',
  'Part' => 'Part',
  'Consumable' => 'Consumable',
  'Machine' => 'Machine',
);

$GLOBALS['app_list_strings']['invoice_status_dom']=array (
  '' => '',
  'Paid' => 'Paid',
  'Unpaid' => 'Unpaid',
  'Cancelled' => 'Cancelled',
);

$GLOBALS['app_list_strings']['pdf_template_type_dom']=array (
  'AOS_Quotes' => 'Quotes',
  'AOS_Invoices' => 'Invoices',
  'AOS_Contracts' => 'Contracts',
  'Accounts' => 'Accounts',
  'Contacts' => 'Contacts',
  'Leads' => 'Leads',
  'tc_terms_conditions' => 'Terms & Conditions',
);