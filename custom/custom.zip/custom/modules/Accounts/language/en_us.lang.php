<?php
// created: 2020-11-13 09:01:42
$mod_strings = array (
  'LBL_INDUSTRY_ROTO' => 'Industry',
  'LBL_TECHNOLOGY_ROTO' => 'Technology',
  'LBL_ACCOUNTS_AOS_PRODUCTS_1_FROM_AOS_PRODUCTS_TITLE' => 'Machines',
  'LBL_OPPORTUNITIES_ACCOUNTS_1_FROM_OPPORTUNITIES_TITLE' => 'Supplier',
  'LBL_EMAIL_ADDRESS' => 'EMAIL',
  'LBL_EDITVIEW_PANEL1' => 'New Panel 1',
  'LBL_TYPE' => 'Type:',
  'LBL_REGION_CODE' => 'Region Code:',
  'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contacts',
  'LBL_PROCESS' => 'Process',
  'LBL_INDUSTRY' => 'Industry:',
  'LBL_VAT_NUMBER' => 'VAT Number',
);