<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2020-05-25 15:14:17
$dictionary["Account"]["fields"]["opportunities_accounts_1"] = array (
  'name' => 'opportunities_accounts_1',
  'type' => 'link',
  'relationship' => 'opportunities_accounts_1',
  'source' => 'non-db',
  'module' => 'Opportunities',
  'bean_name' => 'Opportunity',
  'vname' => 'LBL_OPPORTUNITIES_ACCOUNTS_1_FROM_OPPORTUNITIES_TITLE',
  'id_name' => 'opportunities_accounts_1opportunities_ida',
);
$dictionary["Account"]["fields"]["opportunities_accounts_1_name"] = array (
  'name' => 'opportunities_accounts_1_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_OPPORTUNITIES_ACCOUNTS_1_FROM_OPPORTUNITIES_TITLE',
  'save' => true,
  'id_name' => 'opportunities_accounts_1opportunities_ida',
  'link' => 'opportunities_accounts_1',
  'table' => 'opportunities',
  'module' => 'Opportunities',
  'rname' => 'name',
);
$dictionary["Account"]["fields"]["opportunities_accounts_1opportunities_ida"] = array (
  'name' => 'opportunities_accounts_1opportunities_ida',
  'type' => 'link',
  'relationship' => 'opportunities_accounts_1',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_OPPORTUNITIES_ACCOUNTS_1_FROM_ACCOUNTS_TITLE',
);


// created: 2020-05-10 20:08:56
$dictionary["Account"]["fields"]["accounts_aos_products_1"] = array (
  'name' => 'accounts_aos_products_1',
  'type' => 'link',
  'relationship' => 'accounts_aos_products_1',
  'source' => 'non-db',
  'module' => 'AOS_Products',
  'bean_name' => 'AOS_Products',
  'side' => 'right',
  'vname' => 'LBL_ACCOUNTS_AOS_PRODUCTS_1_FROM_AOS_PRODUCTS_TITLE',
);


 // created: 2020-11-11 13:36:26
$dictionary['Account']['fields']['industry']['len']=100;
$dictionary['Account']['fields']['industry']['inline_edit']=true;
$dictionary['Account']['fields']['industry']['comments']='The company belongs in this industry';
$dictionary['Account']['fields']['industry']['merge_filter']='disabled';

 

 // created: 2020-03-24 18:53:04
$dictionary['Account']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 

 // created: 2020-03-24 18:53:04
$dictionary['Account']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 

 // created: 2020-10-21 19:14:07
$dictionary['Account']['fields']['technology_roto_c']['inline_edit']='1';
$dictionary['Account']['fields']['technology_roto_c']['labelValue']='Technology';

 

 // created: 2020-03-24 18:53:04
$dictionary['Account']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 

 // created: 2020-12-03 12:40:52
$dictionary['Account']['fields']['region_code_c']['inline_edit']='1';
$dictionary['Account']['fields']['region_code_c']['labelValue']='Region Code:';

 

 // created: 2020-03-24 18:53:04
$dictionary['Account']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 

 // created: 2020-10-25 16:04:13
$dictionary['Account']['fields']['process_c']['inline_edit']='1';
$dictionary['Account']['fields']['process_c']['labelValue']='Process';

 

 // created: 2020-11-13 09:01:42
$dictionary['Account']['fields']['vat_number_c']['inline_edit']='1';
$dictionary['Account']['fields']['vat_number_c']['labelValue']='VAT Number';

 

 // created: 2020-05-10 19:11:03
$dictionary['Account']['fields']['industry_roto_c']['inline_edit']='1';
$dictionary['Account']['fields']['industry_roto_c']['labelValue']='Industry';

 

 // created: 2020-11-11 13:37:08
$dictionary['Account']['fields']['account_type']['len']=100;
$dictionary['Account']['fields']['account_type']['required']=true;
$dictionary['Account']['fields']['account_type']['inline_edit']=true;
$dictionary['Account']['fields']['account_type']['comments']='The Company is of this type';
$dictionary['Account']['fields']['account_type']['merge_filter']='disabled';

 
?>