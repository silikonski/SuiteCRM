<?php

class InvoiceLineItems
{
    protected $bean;

    public function __construct(AOS_Invoices $bean)
    {
        $this->bean = $bean;
    }

    function getLineItems($type)
    {
        global $db;

        $items = [];
        if ($type == 'tc_line_items') {
			if (isset($_REQUEST['quote_id']) && !empty($_REQUEST['quote_id'])) {
				$q = "SELECT id FROM aos_products_quotes ";
				$q .= "WHERE parent_type='AOS_Quotes' AND parent_id='{$_REQUEST['quote_id']}' AND deleted=0 AND tc_name is not NULL AND tc_name !='' ORDER BY date_entered";				
			}else{				
				$q = "SELECT id FROM aos_products_quotes ";
				$q .= "WHERE parent_type='AOS_Invoices' AND parent_id='{$this->bean->id}' AND deleted=0 AND tc_name is not NULL AND tc_name !='' ORDER BY date_entered";
			} 
            $q = $db->query($q, true, "GET all saved Line Items for SSF");

            while ($row = $db->fetchByAssoc($q)) {
				$bean = BeanFactory::newBean('AOS_Products_Quotes');
                $bean->retrieve($row['id'], false);
				// $bean = BeanFactory::getBean('AOS_Products_Quotes', $row['id']);
                $items[] = $bean;
            }
        }
		array_multisort(array_map(function($element) {
			return $element->position_c;
			}, $items), SORT_ASC , $items);

        return $items;
    }

    private function unformatMultiEnum($value)
    {
        $formatted = [];

        $values = explode("^,^", $value);
        foreach ($values as $val) {
            $formatted[] = str_replace("^", "", $val);
        }

        return $formatted;
    }
}

/*
 * Display Line Items for Opportunities
 *
 * @param $focus
 * @param $field
 * @param $value
 * @param $view
 *
 * */
function display_tci_lines($focus, $field, $value, $view)
{
    global $app_list_strings, $app_strings;

    $html = '';
    $ss = new Sugar_Smarty();
    $items = [];

    if (isset($focus->id) && !empty($focus->id)) {
        $soli = new InvoiceLineItems($focus);
        $items = $soli->getLineItems($field);
    }
    if (isset($_REQUEST['quote_id']) && !empty($_REQUEST['quote_id'])) {
        $soli = new InvoiceLineItems($focus);
        $items = $soli->getLineItems($field);
    }

    $ss->assign('LINE_ITEMS', $items);

    $ss->assign('TYPE', $field);
    $ss->assign('APP_STRINGS', $app_strings);
    $ss->assign('APP_LIST_STRINGS', $app_list_strings);

    if ($view == 'EditView') {
        $html .= $ss->fetch('custom/modules/AOS_Invoices/tpls/EditViewLineItems.tpl');
    } elseif ($view == 'DetailView') {
        $html .= $ss->fetch('custom/modules/AOS_Invoices/tpls/DetailViewLineItems.tpl');
    }

    return $html;
}
