<?php
// created: 2021-01-20 06:43:36
$mod_strings = array (
  'LBL_INVOICE_KEY' => 'Invoice Key:',
  'LBL_DELIVERY_DATE' => 'Delivery Date:',
  'LBL_DELIVERYCW' => 'Delivery Week:',
  'LBL_DELIVERYYEAR' => 'Delivery Year:',
  'AOS_Quotes' => 'Quotes',
  'LBL_STATUS' => 'Status',
  'LBL_EDITVIEW_PANEL1' => 'Terms and Conditions',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_INVOICE_PAYMENT_TERMS' => 'Payment Terms:',
  'LBL_SHIPPING_TERMS' => 'Shipping Terms:',
  'LBL_EXTERNAL_INVOICE_REFERENCE' => 'Supplier Invoice Number:',
  'LBL_INVOICE_ISSUER' => 'Invoice Issuer:',
  'LBL_INV_SALES_ORDER_NUMBER' => 'Sales Order Number',
  'LBL_PRIVREMENA_KALKULACIJA' => 'Privremena kalkulacija',
  'LBL_TC_LINE_ITEMS' => 'Line Items',
);