<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}


class AOS_InvoicesViewEdit extends ViewEdit
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @deprecated deprecated since version 7.6, PHP4 Style Constructors are deprecated and will be remove in 7.8, please update your code, use __construct instead
     */
    public function AOS_InvoicesViewEdit()
    {
        $deprecatedMessage = 'PHP4 Style Constructors are deprecated and will be remove in 7.8, please update your code';
        if (isset($GLOBALS['log'])) {
            $GLOBALS['log']->deprecated($deprecatedMessage);
        } else {
            trigger_error($deprecatedMessage, E_USER_DEPRECATED);
        }
        self::__construct();
    }

    function getLineItem()
    {
        global $db;

        $items = [];
		
			if (isset($_REQUEST['quote_id']) && !empty($_REQUEST['quote_id'])) {
				$q = "SELECT id FROM aos_products_quotes ";
				$q .= "WHERE parent_type='AOS_Quotes' AND parent_id='{$_REQUEST['quote_id']}' AND deleted=0 AND tc_name is not NULL AND tc_name !='' ORDER BY date_entered";				
			}else{				
				$q = "SELECT id FROM aos_products_quotes ";
				$q .= "WHERE parent_type='AOS_Invoices' AND parent_id='{$this->bean->id}' AND deleted=0 AND tc_name is not NULL AND tc_name !='' ORDER BY date_entered";
			}
			
			
            $q = $db->query($q, true, "GET all saved Line Items for TC");

            while ($row = $db->fetchByAssoc($q)) {
                $bean = BeanFactory::getBean('AOS_Products_Quotes', $row['id']);
                $items[] = $bean;
            }

        return $items;
    }
    public function display()
    {
        $this->populateInvoiceTemplates();
		if (isset($_REQUEST['quote_id']) && !empty($_REQUEST['quote_id'])) {
			$quote = BeanFactory::newBean('AOS_Quotes');
			$quote->retrieve($_REQUEST['quote_id']);		
			$rawRow = $quote->fetched_row;	
			foreach($rawRow as $field=>$value){
				if($field !='id'){				
					$this->bean->$field  = $_REQUEST[$field]= $quote->$field;
				}
			}
			
			$this->bean->billing_account = $_REQUEST['billing_account']=$quote->billing_account;
			$this->bean->billing_contact = $_REQUEST['billing_contact']=$quote->billing_contact;
			$this->bean->billing_contact_id = $_REQUEST['billing_contact_id']=$quote->billing_contact_id; 
		}
        parent::display();

	   $items = [];

		if (isset($this->bean->id) && !empty($this->bean->id)) {
			$items = $this->getLineItem();
		}
		if (isset($_REQUEST['quote_id']) && !empty($_REQUEST['quote_id'])) {
			$items = $this->getLineItem();
		}
		$this->ss->assign('COUNT', count($items));
		
		$this->ss->display('custom/modules/AOS_Invoices/tpls/EditView.tpl');
    }

    public function populateInvoiceTemplates()
    {
        global $app_list_strings;

        $sql = "SELECT id, name FROM aos_pdf_templates WHERE deleted='0' AND type='AOS_Invoices'";
        $res = $this->bean->db->query($sql);

        $app_list_strings['template_ddown_c_list'] = array();
        while ($row = $this->bean->db->fetchByAssoc($res)) {
            $app_list_strings['template_ddown_c_list'][$row['id']] = $row['name'];
        }
    }
}
