<?php 
 //WARNING: The contents of this file are auto-generated


$dictionary['AOS_Invoices']['fields']['tc_line_items'] = array (
    'required' => false,
    'name' => 'tc_line_items',
    'vname' => 'LBL_TC_LINE_ITEMS',
    'type' => 'function',
    'source' => 'non-db',
    'massupdate' => 0,
    'importable' => 'false',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => 0,
    'audited' => false,
    'reportable' => false,
    'inline_edit' => false,
    'studio' => 'visible',
    'function' =>
        array(
            'name' => 'display_tci_lines',
            'returns' => 'html',
            'include' => 'custom/modules/AOS_Invoices/Line_Items.php'
        ),
);
$dictionary['AOS_Invoices']['fields']['line_items'] = array (
      'required' => false,
      'name' => 'line_items',
      'vname' => 'LBL_LINE_ITEMS',
      'type' => 'function',
      'source' => 'non-db',
      'massupdate' => 0,
      'importable' => 'false',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => 0,
      'audited' => false,
      'reportable' => false,
      'inline_edit' => false,
      'function' => 
      array (
        'name' => 'display_invoice_lines',
        'returns' => 'html',
        'include' => 'custom/modules/AOS_Products_Quotes/Line_Items.php',
      ),
);



 // created: 2020-11-08 20:53:06
$dictionary['AOS_Invoices']['fields']['invnum_related_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['invnum_related_c']['options']='numeric_range_search_dom';
$dictionary['AOS_Invoices']['fields']['invnum_related_c']['labelValue']='Relative Invoice Number:';
$dictionary['AOS_Invoices']['fields']['invnum_related_c']['enable_range_search']='1';

 

 // created: 2021-01-03 18:50:35
$dictionary['AOS_Invoices']['fields']['description']['inline_edit']=true;
$dictionary['AOS_Invoices']['fields']['description']['comments']='Full text of the note';
$dictionary['AOS_Invoices']['fields']['description']['merge_filter']='disabled';
$dictionary['AOS_Invoices']['fields']['description']['rows']='4';

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Invoices']['fields']['inv_sales_order_number_c']['inline_edit']=1;

 

 // created: 2020-12-12 10:43:40
$dictionary['AOS_Invoices']['fields']['issuer_sales_order_number_c']['inline_edit']='';
$dictionary['AOS_Invoices']['fields']['issuer_sales_order_number_c']['labelValue']='Issuer Sales Order';

 

 // created: 2020-11-08 21:49:57
$dictionary['AOS_Invoices']['fields']['company_selection_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['company_selection_c']['labelValue']='Invoice Issuer:';

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Invoices']['fields']['invoice_payment_terms_c']['inline_edit']=1;

 

 // created: 2020-12-21 15:38:16
$dictionary['AOS_Invoices']['fields']['opsalenum_c']['inline_edit']='';
$dictionary['AOS_Invoices']['fields']['opsalenum_c']['labelValue']='Sales Order Number';

 

 // created: 2020-11-08 22:06:13
$dictionary['AOS_Invoices']['fields']['payment_terms_c']['inline_edit']='1';
$dictionary['AOS_Invoices']['fields']['payment_terms_c']['labelValue']='Payment Terms';

 

 // created: 2021-01-03 18:46:59
$dictionary['AOS_Invoices']['fields']['status']['required']=true;
$dictionary['AOS_Invoices']['fields']['status']['inline_edit']=true;
$dictionary['AOS_Invoices']['fields']['status']['merge_filter']='disabled';

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Invoices']['fields']['deliveryyear_c']['inline_edit']=1;

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Invoices']['fields']['privremena_kalkulacija_c']['inline_edit']=1;

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Invoices']['fields']['external_invoice_reference_c']['inline_edit']=1;

 

 // created: 2021-01-20 06:43:36
$dictionary['AOS_Invoices']['fields']['tc_line_items']['merge_filter']='disabled';
$dictionary['AOS_Invoices']['fields']['tc_line_items']['reportable']=true;

 

 // created: 2021-01-10 12:12:08
$dictionary['AOS_Invoices']['fields']['aos_quotes_id_c']['inline_edit']=1;

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Invoices']['fields']['delivery_date_c']['inline_edit']=1;

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Invoices']['fields']['invoice_key_c']['inline_edit']=1;

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Invoices']['fields']['shipping_terms_c']['inline_edit']=1;

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Invoices']['fields']['deliverycw_c']['inline_edit']=1;

 

 // created: 2021-01-10 12:12:08
$dictionary['AOS_Invoices']['fields']['inv_relatefield_quote_c']['inline_edit']='';
$dictionary['AOS_Invoices']['fields']['inv_relatefield_quote_c']['labelValue']='inv relatefield quote';

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Invoices']['fields']['invoice_issuer_c']['inline_edit']=1;

 
?>