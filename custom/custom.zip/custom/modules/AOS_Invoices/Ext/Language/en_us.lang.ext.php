<?php 
 //WARNING: The contents of this file are auto-generated

 
 // created: 2021-03-31 12:07:05
$mod_strings['LBL_INVOICE_KEY'] = 'Invoice Key:';
$mod_strings['LBL_DELIVERY_DATE'] = 'Delivery Date:';
$mod_strings['LBL_DELIVERYCW'] = 'Delivery Week:';
$mod_strings['LBL_DELIVERYYEAR'] = 'Delivery Year:';
$mod_strings['AOS_Quotes'] = 'Quotes';
$mod_strings['LBL_STATUS'] = 'Status';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Terms and Conditions';
$mod_strings['LBL_DESCRIPTION'] = 'Description';
$mod_strings['LBL_INVOICE_PAYMENT_TERMS'] = 'Payment Terms:';
$mod_strings['LBL_SHIPPING_TERMS'] = 'Shipping Terms:';
$mod_strings['LBL_EXTERNAL_INVOICE_REFERENCE'] = 'Supplier Invoice Number:';
$mod_strings['LBL_INVOICE_ISSUER'] = 'Invoice Issuer:';
$mod_strings['LBL_INV_SALES_ORDER_NUMBER'] = 'Sales Order Number';
$mod_strings['LBL_PRIVREMENA_KALKULACIJA'] = 'Privremena kalkulacija';
$mod_strings['LBL_TC_LINE_ITEMS'] = 'Line Items';



?>