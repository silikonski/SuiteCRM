<?php
class customHook {
    public function saveRelationship($bean, $event, $args)
    {	
		if (isset($_REQUEST['quote_id']) && !empty($_REQUEST['quote_id'])) {			
			$quote = BeanFactory::newBean('AOS_Quotes');
			$quote->retrieve($_REQUEST['quote_id']);
			require_once('modules/Relationships/Relationship.php');
			$key = Relationship::retrieve_by_modules('AOS_Quotes', 'AOS_Invoices', $GLOBALS['db']);
			if (!empty($key)) {
				$quote->load_relationship($key);
				$quote->$key->add($bean->id);
			}			
		}
	}
    public function saveLineItems($bean, $event, $args)
    {	
		if (isset($_REQUEST['quote_id']) && !empty($_REQUEST['quote_id'])) {			
			$quote = BeanFactory::newBean('AOS_Quotes');
			$quote->retrieve($_REQUEST['quote_id']);
			if(!empty($quote->opportunity_id)){
				$opp = new Opportunity();
				$opp->retrieve($quote->opportunity_id);
				$opp->sales_stage="Closed Won";
				$opp->save();
				$quote->sales_order_nomber_c = $opp->sales_order_nomber_c;
			}
			$quote->invoice_status = 'Invoiced';
			$quote->save();
			$bean->inv_sales_order_number_c = $quote->sales_order_nomber_c;
			$bean->invoice_issuer_c = $quote->company_selection_c;
			$bean->invoice_key_c = $quote->quote_key_c;			
		}

        if ($_REQUEST['module']=='AOS_Invoices' && isset($_REQUEST['line_item_id']) && is_array($_REQUEST['line_item_id']) && isset($_REQUEST['action']) && $_REQUEST['action']=='Save') {
			$existingItems = $this->getAllSavedItems($bean->id);
			$savedItems = [];
            foreach ($_REQUEST['line_item_id'] as $type => $items) {
                foreach ($items as $i => $item) {
                    $lineItem = BeanFactory::newBean('AOS_Products_Quotes');
                    // if (!empty($item)) {
                        // $lineItem->retrieve($item);
                        // if (empty($lineItem->id)) {
                            // $lineItem->id = $item;
                            // $lineItem->new_with_id = true;
                        // }
                    // }
					if(!empty($_REQUEST['tc_name'][$type][$i])){

						$lineItem->tc_name = $_REQUEST['tc_name'][$type][$i];
						$lineItem->tc_description = $_REQUEST['tc_description'][$type][$i];
						$lineItem->parent_type = 'AOS_Invoices';
						$lineItem->parent_id = $bean->id;
						$savedItems[] = $lineItem->save();
					}
                }
            }
			
			if (!empty($existingItems)) {
				foreach ($existingItems as $existingItem) {
					if (!in_array($existingItem, $savedItems)) {
						BeanFactory::newBean('AOS_Products_Quotes')->mark_deleted($existingItem);
					}
				}
			}
        }

    }

    /*
     * Get All Saved Line Items for SO
     *
     * @param $so_id
     * @return $ids;
     * */
    protected function getAllSavedItems($ssf_id)
    {
        global $db;

        $q = "SELECT id FROM aos_products_quotes ";
        $q .= "WHERE parent_type='AOS_Invoices' AND parent_id='{$ssf_id}' AND deleted=0 AND tc_name is not NULL AND tc_name !=''";
        $q = $db->query($q, true, "GET all saved Line Items for SSF");
        $ids = [];
        while ($row = $db->fetchByAssoc($q)) {
            $ids[] = $row['id'];
        }

        return $ids;
    }	
}