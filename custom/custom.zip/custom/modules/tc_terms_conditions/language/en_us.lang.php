<?php
// created: 2021-03-23 21:58:06
$mod_strings = array (
  'LBL_ISSUER' => 'Issuer',
);