<?php 
 //WARNING: The contents of this file are auto-generated

 
 // created: 2021-03-31 12:07:07
$mod_strings['LBL_ISSUER'] = 'Issuer';



?>