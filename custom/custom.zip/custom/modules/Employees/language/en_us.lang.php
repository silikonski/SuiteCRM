<?php
// created: 2021-10-16 05:55:47
$mod_strings = array (
  'LBL_REGION' => 'region',
  'LBL_REGION_C' => 'region c',
);