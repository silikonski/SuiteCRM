<?php 
 //WARNING: The contents of this file are auto-generated


$layout_defs['AOS_Quotes']['subpanel_setup']['aos_quotes_aos_invoices'] =     array(
        'order' => 100,
        'module' => 'AOS_Invoices',
        'subpanel_name' => 'default',
        'sort_order' => 'asc',
        'sort_by' => 'id',
        'title_key' => 'AOS_Invoices',
        'get_subpanel_data' => 'aos_quotes_aos_invoices',
        'top_buttons' =>
        array(
                0 =>
             array(
                'widget_class' => 'SubPanelTopCreateButton',
            ),
        ),
    );
?>