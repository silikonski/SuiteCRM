<?php 
 //WARNING: The contents of this file are auto-generated

 
 // created: 2021-03-31 12:07:06
$mod_strings['LBL_TERM'] = 'Payment Terms DropDown';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Terms and Conditions';
$mod_strings['LBL_COMPANY_SELECTION'] = 'Quote Issuer:';
$mod_strings['LBL_STAGE'] = 'Quote Stage';
$mod_strings['LBL_DETAILVIEW_PANEL1'] = 'Terms and Conditions';
$mod_strings['LBL_DELIVERYCW'] = 'Delivery Week:';
$mod_strings['LBL_DELIVERYTIME'] = 'Delivery Date:';
$mod_strings['LBL_DELIVERYYEAR'] = 'Delivery Year';
$mod_strings['LBL_QUOTE_KEY'] = 'Quote Key:';
$mod_strings['LBL_DETAILVIEW_PANEL2'] = 'New Panel 2';
$mod_strings['LBL_QUOTENUM_RELATED'] = 'Relative Quote Number:';
$mod_strings['LBL_EXTERNAL_QUOTE_REFERENCE'] = 'Supplier Quote Number:';
$mod_strings['LBL_DATE_CREATED_FORMATTED'] = 'Formatted Creation Date:';
$mod_strings['LBL_SALES_ORDER_NOMBER'] = 'Sales Order Number';
$mod_strings['LBL_PAYMENT_TERMS'] = 'Payment Terms:';
$mod_strings['LBL_TERMS_CHECKBOX'] = 'Set Default Terms';
$mod_strings['LBL_EXPIRATION'] = 'Valid Until';
$mod_strings['LBL_SHIPPING_TERMS'] = 'Shipping Terms:';
$mod_strings['LBL_TC_LINE_ITEMS'] = 'Line items';



?>