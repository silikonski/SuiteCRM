<?php 
 //WARNING: The contents of this file are auto-generated


$dictionary['AOS_Quotes']['fields']['tc_line_items'] = array (
    'required' => false,
    'name' => 'tc_line_items',
    'vname' => 'LBL_TC_LINE_ITEMS',
    'type' => 'function',
    'source' => 'non-db',
    'massupdate' => 0,
    'importable' => 'false',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => 0,
    'audited' => false,
    'reportable' => false,
    'inline_edit' => false,
    'studio' => 'visible',
    'function' =>
        array(
            'name' => 'display_tc_lines',
            'returns' => 'html',
            'include' => 'custom/modules/AOS_Quotes/Line_Items.php'
        ),
);
$dictionary['AOS_Quotes']['fields']['shipping_tax_amt'] = array(
	'required' => false,
	'name' => 'shipping_tax_amt',
	'vname' => 'LBL_SHIPPING_TAX_AMT',
	'type' => 'currency',
	'massupdate' => 0,
	'comments' => '',
	'help' => '',
	'importable' => 'true',
	'duplicate_merge' => 'disabled',
	'duplicate_merge_dom_value' => '0',
	'audited' => 0,
	'reportable' => true,
	'len' => '26,6',
	'size' => '10',
	'enable_range_search' => false,
	'function' =>
		array(
			'name' => 'display_shipping_vat',
			'returns' => 'html',
			'include' => 'custom/modules/AOS_Products_Quotes/Line_Items.php'
		),
);
$dictionary['AOS_Quotes']['fields']['line_items'] = array(
	'required' => false,
	'name' => 'line_items',
	'vname' => 'LBL_LINE_ITEMS',
	'type' => 'function',
	'source' => 'non-db',
	'massupdate' => 0,
	'importable' => 'false',
	'duplicate_merge' => 'disabled',
	'duplicate_merge_dom_value' => 0,
	'audited' => false,
	'reportable' => false,
	'inline_edit' => false,
	'function' =>
		array(
			'name' => 'display_lines',
			'returns' => 'html',
			'include' => 'custom/modules/AOS_Products_Quotes/Line_Items.php'
		),
);

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Quotes']['fields']['company_selection_c']['inline_edit']=1;

 

 // created: 2020-10-30 08:55:33
$dictionary['AOS_Quotes']['fields']['quote_editor_c']['labelValue']='quote editor';

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Quotes']['fields']['payment_terms_c']['inline_edit']=1;

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Quotes']['fields']['external_quote_reference_c']['inline_edit']=1;

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Quotes']['fields']['sales_order_nomber_c']['inline_edit']=1;

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Quotes']['fields']['quotenum_related_c']['inline_edit']=1;

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Quotes']['fields']['deliveryyear_c']['inline_edit']=1;

 

 // created: 2020-11-08 17:53:58
$dictionary['AOS_Quotes']['fields']['delivery_week_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['delivery_week_c']['labelValue']='delivery week';

 

 // created: 2021-01-03 17:10:23
$dictionary['AOS_Quotes']['fields']['expiration']['display_default']='+1 month';
$dictionary['AOS_Quotes']['fields']['expiration']['inline_edit']=true;
$dictionary['AOS_Quotes']['fields']['expiration']['merge_filter']='disabled';

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Quotes']['fields']['date_created_formatted_c']['inline_edit']=1;

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Quotes']['fields']['deliverytime_c']['inline_edit']=1;

 

 // created: 2021-01-03 16:28:54

 

 // created: 2020-11-08 13:15:40
$dictionary['AOS_Quotes']['fields']['stage']['required']=false;
$dictionary['AOS_Quotes']['fields']['stage']['inline_edit']=true;
$dictionary['AOS_Quotes']['fields']['stage']['merge_filter']='disabled';

 

 // created: 2021-01-21 10:02:06
$dictionary['AOS_Quotes']['fields']['tc_line_items']['merge_filter']='disabled';
$dictionary['AOS_Quotes']['fields']['tc_line_items']['reportable']=true;

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Quotes']['fields']['quote_key_c']['inline_edit']=1;

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Quotes']['fields']['terms_checkbox_c']['inline_edit']=1;

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Quotes']['fields']['shipping_terms_c']['inline_edit']=1;

 

 // created: 2021-07-08 16:42:32
$dictionary['AOS_Quotes']['fields']['deliverycw_c']['inline_edit']=1;

 
?>