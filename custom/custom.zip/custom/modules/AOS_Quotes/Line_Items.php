<?php

class AOS_QuotesLineItems
{
    protected $bean;

    public function __construct(AOS_Quotes $bean)
    {
        $this->bean = $bean;
    }

    function getLineItems($type)
    {
        global $db;

        $items = [];
        if ($type == 'tc_line_items') {
            $q = "SELECT id FROM aos_products_quotes ";
            $q .= "WHERE parent_type='AOS_Quotes' AND parent_id='{$this->bean->id}' AND deleted=0 AND tc_name is not NULL AND tc_name !='' ORDER BY date_entered";
            $q = $db->query($q, true, "GET all saved Line Items for SSF");

            while ($row = $db->fetchByAssoc($q)) {
				$bean = BeanFactory::newBean('AOS_Products_Quotes');
                $bean->retrieve($row['id'], false);
                $items[] = $bean;
            }
        }
		array_multisort(array_map(function($element) {
			return $element->position_c;
			}, $items), SORT_ASC , $items);
        return $items;
    }

    private function unformatMultiEnum($value)
    {
        $formatted = [];

        $values = explode("^,^", $value);
        foreach ($values as $val) {
            $formatted[] = str_replace("^", "", $val);
        }

        return $formatted;
    }
}

/*
 * Display Line Items for Opportunities
 *
 * @param $focus
 * @param $field
 * @param $value
 * @param $view
 *
 * */
function display_tc_lines($focus, $field, $value, $view)
{
    global $app_list_strings, $app_strings,$db;

    $html = '';
    $ss = new Sugar_Smarty();
    $items = [];

    if (isset($focus->id) && !empty($focus->id)) {
        $soli = new AOS_QuotesLineItems($focus);
        $items = $soli->getLineItems($field);
    }else{
		if (isset($focus->opportunity_id) && !empty($focus->opportunity_id)) {				
			$opportunity = BeanFactory::getBean('Opportunities', $focus->opportunity_id);
			if (isset($opportunity->opp_quote_issuer_c) && !empty($opportunity->opp_quote_issuer_c)) {				
				$q = "SELECT tc_terms_conditions.id,tc_terms_conditions.name,tc_terms_conditions.description 
				FROM tc_terms_conditions 
				INNER JOIN tc_terms_conditions_cstm ON tc_terms_conditions_cstm.id_c  = tc_terms_conditions.id 
				WHERE  tc_terms_conditions.deleted=0 AND tc_terms_conditions_cstm.issuer_c='{$opportunity->opp_quote_issuer_c}' 
				";
				$q = $db->query($q, true, "GET all saved Line Items for SSF");
				while ($row = $db->fetchByAssoc($q)) {
					$bean = BeanFactory::getBean('AOS_Products_Quotes', $row['id']);
					$bean->tc_name = $row['name'];
					$bean->tc_description = $row['description'];
					$bean->product_id = $row['id'];
					$items[] = $bean;				
					
				}			
			}
		}
	}
// print"<pre>";print_r( $items);die;
    $ss->assign('LINE_ITEMS', $items);

    $ss->assign('TYPE', $field);
    $ss->assign('APP_STRINGS', $app_strings);
    $ss->assign('APP_LIST_STRINGS', $app_list_strings);

    if ($view == 'EditView') {
        $html .= $ss->fetch('custom/modules/AOS_Quotes/tpls/EditViewLineItems.tpl');
    } elseif ($view == 'DetailView') {
        $html .= $ss->fetch('custom/modules/AOS_Quotes/tpls/DetailViewLineItems.tpl');
    }

    return $html;
}
