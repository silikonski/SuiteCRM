<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}
/**
 * Advanced OpenSales, Advanced, robust set of sales modules.
 * @package Advanced OpenSales for SugarCRM
 * @copyright SalesAgility Ltd http://www.salesagility.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU AFFERO GENERAL PUBLIC LICENSE as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU AFFERO GENERAL PUBLIC LICENSE
 * along with this program; if not, see http://www.gnu.org/licenses
 * or write to the Free Software Foundation,Inc., 51 Franklin Street,
 * Fifth Floor, Boston, MA 02110-1301  USA
 *
 * @author SalesAgility <info@salesagility.com>
 */



class AOS_QuotesViewEdit extends ViewEdit
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * @deprecated deprecated since version 7.6, PHP4 Style Constructors are deprecated and will be remove in 7.8, please update your code, use __construct instead
     */
    public function AOS_QuotesViewEdit()
    {
        $deprecatedMessage = 'PHP4 Style Constructors are deprecated and will be remove in 7.8, please update your code';
        if (isset($GLOBALS['log'])) {
            $GLOBALS['log']->deprecated($deprecatedMessage);
        } else {
            trigger_error($deprecatedMessage, E_USER_DEPRECATED);
        }
        self::__construct();
    }


 
  function getLineItem()
    {
        global $db;

        $items = [];
            $q = "SELECT id FROM aos_products_quotes ";
            $q .= "WHERE parent_type='AOS_Quotes' AND parent_id='{$this->bean->id}' AND deleted=0 AND tc_name is not NULL AND tc_name !='' ORDER BY date_entered";
            $q = $db->query($q, true, "GET all saved Line Items for TC");

            while ($row = $db->fetchByAssoc($q)) {
                $bean = BeanFactory::getBean('AOS_Products_Quotes', $row['id']);
                $items[] = $bean;
            }

        return $items;
    }
    public function display()
    {
		global $db;
        $this->populateQuoteTemplates();
        parent::display();

		$items = [];

		if (isset($this->bean->id) && !empty($this->bean->id)) {
			$items = $this->getLineItem();
		}else{
			if (isset($this->bean->opportunity_id) && !empty($this->bean->opportunity_id)) {				
				$opportunity = BeanFactory::getBean('Opportunities', $this->bean->opportunity_id);
				if (isset($opportunity->opp_quote_issuer_c) && !empty($opportunity->opp_quote_issuer_c)) {				
					$q = "SELECT tc_terms_conditions.id,tc_terms_conditions.name,tc_terms_conditions.description 
					FROM tc_terms_conditions 
					INNER JOIN tc_terms_conditions_cstm ON tc_terms_conditions_cstm.id_c  = tc_terms_conditions.id 
					WHERE  tc_terms_conditions.deleted=0 AND tc_terms_conditions_cstm.issuer_c='{$opportunity->opp_quote_issuer_c}' 
					";
					$q = $db->query($q, true, "GET all saved Line Items for SSF");
					while ($row = $db->fetchByAssoc($q)) {
						$bean = BeanFactory::getBean('AOS_Products_Quotes', $row['id']);
						$bean->tc_name = $row['name'];
						$bean->tc_description = $row['description'];
						$bean->product_id = $row['id'];
						$items[] = $bean;				
						
					}			
				}
			}
	}
		$this->ss->assign('COUNT', count($items));
		
		$this->ss->display('custom/modules/AOS_Quotes/tpls/EditView.tpl');
    }
    public function populateQuoteTemplates()
    {
        global $app_list_strings;

        $sql = "SELECT id, name FROM aos_pdf_templates WHERE deleted='0' AND type='AOS_Quotes'";
        $res = $this->bean->db->query($sql);

        $app_list_strings['template_ddown_c_list'] = array();
        while ($row = $this->bean->db->fetchByAssoc($res)) {
            $app_list_strings['template_ddown_c_list'][$row['id']] = $row['name'];
        }
    }
}
