<?php
// created: 2021-07-08 09:48:42
$mod_strings = array (
  'LBL_TERM' => 'Payment Terms DropDown',
  'LBL_EDITVIEW_PANEL1' => 'Terms and Conditions',
  'LBL_COMPANY_SELECTION' => 'Quote Issuer:',
  'LBL_STAGE' => 'Quote Stage',
  'LBL_DETAILVIEW_PANEL1' => 'Terms and Conditions',
  'LBL_DELIVERYCW' => 'Delivery Week:',
  'LBL_DELIVERYTIME' => 'Delivery Date:',
  'LBL_DELIVERYYEAR' => 'Delivery Year',
  'LBL_QUOTE_KEY' => 'Quote Key:',
  'LBL_DETAILVIEW_PANEL2' => 'New Panel 2',
  'LBL_QUOTENUM_RELATED' => 'Relative Quote Number:',
  'LBL_EXTERNAL_QUOTE_REFERENCE' => 'Supplier Quote Number:',
  'LBL_DATE_CREATED_FORMATTED' => 'Formatted Creation Date:',
  'LBL_SALES_ORDER_NOMBER' => 'Sales Order Number',
  'LBL_PAYMENT_TERMS' => 'Payment Terms:',
  'LBL_TERMS_CHECKBOX' => 'Set Default Terms',
  'LBL_EXPIRATION' => 'Valid Until',
  'LBL_SHIPPING_TERMS' => 'Shipping Terms:',
  'LBL_TC_LINE_ITEMS' => 'Line items',
  'LBL_POSITION' => 'Position',
);