<?php
class customHookAOS_Quotes {
    public function saveLineItems($bean, $event, $args)
    { 
		if ($_REQUEST['module']=='AOS_Quotes' && isset($_REQUEST['action']) && $_REQUEST['action']=='Save') {
			$query =  "SELECT quote.opportunity_id FROM aos_quotes as quote";
			$current_record = $_REQUEST['record'];
			$query .= " WHERE  quote.id = '$current_record' LIMIT 1";
			$results = $bean->db->query($query, true);
			$row = $bean->db->fetchByAssoc($results);
			$current_opportunity_id = $row['opportunity_id'];

			$referrer_url = $_SERVER['HTTP_REFERER'];
			$parsed = parse_url($referrer_url);
			$referrerset = isset($parsed['query']);

			if($_REQUEST['opportunity_id']!=$current_opportunity_id && $referrerset){
				$opportunity = BeanFactory::getBean('Opportunities',$_REQUEST['opportunity_id']);
				if (isset($opportunity->opp_quote_issuer_c) && !empty($opportunity->opp_quote_issuer_c)) {
					$q = "SELECT tc_terms_conditions.id,tc_terms_conditions.name,tc_terms_conditions.description
					FROM tc_terms_conditions
					INNER JOIN tc_terms_conditions_cstm ON tc_terms_conditions_cstm.id_c  = tc_terms_conditions.id 
					WHERE  tc_terms_conditions.deleted=0 AND tc_terms_conditions_cstm.issuer_c='{$opportunity->opp_quote_issuer_c}' 
					";
					$q = $bean->db->query($q, true, "GET all saved Line Items for SSF");
					$_REQUEST['tc_name']['tc_line_items'] = array();
					$_REQUEST['tc_description']['tc_line_items'] = array();
					if(!isset($_REQUEST['line_item_id'])){
						$_REQUEST['line_item_id'] = [];
					}
					if(!isset($_REQUEST['line_item_id']['tc_line_items'])){
						$_REQUEST['line_item_id']['tc_line_items'] = [];
					}
					while ($row = $bean->db->fetchByAssoc($q)) {
						$_REQUEST['tc_description']['tc_line_items'][] = $row['description'];
						$_REQUEST['tc_name']['tc_line_items'][] = $row['name'];
						$_REQUEST['line_item_id']['tc_line_items'][] = null;
					}
					$bean->company_selection_c = $opportunity->opp_quote_issuer_c;
					$bean->quote_key_c = explode("-",$bean->quote_key_c)[0] . '-' . $opportunity->opportunity_key_c;
				}
			}
		}
        if ($_REQUEST['module']=='AOS_Quotes' && isset($_REQUEST['line_item_id']) && is_array($_REQUEST['line_item_id']) && isset($_REQUEST['action']) && $_REQUEST['action']=='Save') {
			$existingItems = $this->getAllSavedItems($bean->id);
			$savedItems = [];
			foreach ($_REQUEST['line_item_id'] as $type => $items) {
                foreach ($items as $i => $item) {
                    $lineItem = BeanFactory::newBean('AOS_Products_Quotes');
                    if (!empty($item)) {
                        $lineItem->retrieve($item);
                        if (empty($lineItem->id)) {
                            $lineItem->id = $item;
                            $lineItem->new_with_id = true;
                        }
                    }
					if(!empty($_REQUEST['tc_name'][$type][$i])){
						$lineItem->tc_name = $_REQUEST['tc_name'][$type][$i];
						$lineItem->tc_description = $_REQUEST['tc_description'][$type][$i];
						$lineItem->position_c = $_REQUEST['tc_position'][$type][$i];						
						$lineItem->parent_type = 'AOS_Quotes';
						$lineItem->parent_id = $bean->id;
						$savedItems[] = $lineItem->save();
					}
                }
            }
			if (!empty($existingItems)) {
				foreach ($existingItems as $existingItem) {
					if (!in_array($existingItem, $savedItems)) {
						BeanFactory::newBean('AOS_Products_Quotes')->mark_deleted($existingItem);
					}
				}
			}
        }

    }

    /*
     * Get All Saved Line Items for SO
     *
     * @param $so_id
     * @return $ids;
     * */
    protected function getAllSavedItems($ssf_id)
    {
        global $db;

        $q = "SELECT id FROM aos_products_quotes ";
        $q .= "WHERE parent_type='AOS_Quotes' AND parent_id='{$ssf_id}' AND deleted=0 AND tc_name is not NULL AND tc_name !=''";
        $q = $db->query($q, true, "GET all saved Line Items for SSF");
        $ids = [];
        while ($row = $db->fetchByAssoc($q)) {
            $ids[] = $row['id'];
        }

        return $ids;
    }	
}