<?php
// created: 2021-10-07 06:23:15
$mod_strings = array (
  'LBL_REGION' => 'region',
);