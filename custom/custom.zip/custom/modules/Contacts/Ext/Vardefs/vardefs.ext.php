<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2020-05-26 14:20:03
$dictionary["Contact"]["fields"]["aos_products_contacts_1"] = array (
  'name' => 'aos_products_contacts_1',
  'type' => 'link',
  'relationship' => 'aos_products_contacts_1',
  'source' => 'non-db',
  'module' => 'AOS_Products',
  'bean_name' => 'AOS_Products',
  'vname' => 'LBL_AOS_PRODUCTS_CONTACTS_1_FROM_AOS_PRODUCTS_TITLE',
  'id_name' => 'aos_products_contacts_1aos_products_ida',
);
$dictionary["Contact"]["fields"]["aos_products_contacts_1_name"] = array (
  'name' => 'aos_products_contacts_1_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_AOS_PRODUCTS_CONTACTS_1_FROM_AOS_PRODUCTS_TITLE',
  'save' => true,
  'id_name' => 'aos_products_contacts_1aos_products_ida',
  'link' => 'aos_products_contacts_1',
  'table' => 'aos_products',
  'module' => 'AOS_Products',
  'rname' => 'name',
);
$dictionary["Contact"]["fields"]["aos_products_contacts_1aos_products_ida"] = array (
  'name' => 'aos_products_contacts_1aos_products_ida',
  'type' => 'link',
  'relationship' => 'aos_products_contacts_1',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_AOS_PRODUCTS_CONTACTS_1_FROM_CONTACTS_TITLE',
);


 // created: 2020-10-27 08:19:25
$dictionary['Contact']['fields']['birthdate']['inline_edit']=true;
$dictionary['Contact']['fields']['birthdate']['options']='date_range_search_dom';
$dictionary['Contact']['fields']['birthdate']['comments']='The birthdate of the contact';
$dictionary['Contact']['fields']['birthdate']['merge_filter']='disabled';
$dictionary['Contact']['fields']['birthdate']['enable_range_search']='1';

 

 // created: 2020-03-24 18:53:05
$dictionary['Contact']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 

 // created: 2020-03-24 18:53:04
$dictionary['Contact']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 

 // created: 2020-03-24 18:53:04
$dictionary['Contact']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 

 // created: 2020-03-24 18:53:04
$dictionary['Contact']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 
?>