<?php
// created: 2020-10-27 08:19:25
$mod_strings = array (
  'LBL_BIRTHDATE' => 'Birthdate:',
);