<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2020-05-25 15:14:17
$dictionary["Opportunity"]["fields"]["opportunities_accounts_1"] = array (
  'name' => 'opportunities_accounts_1',
  'type' => 'link',
  'relationship' => 'opportunities_accounts_1',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'side' => 'right',
  'vname' => 'LBL_OPPORTUNITIES_ACCOUNTS_1_FROM_ACCOUNTS_TITLE',
);


 // created: 2020-10-25 15:44:47
$dictionary['Opportunity']['fields']['date_closed']['required']=false;
$dictionary['Opportunity']['fields']['date_closed']['inline_edit']=true;
$dictionary['Opportunity']['fields']['date_closed']['comments']='Expected or actual date the oppportunity will close';
$dictionary['Opportunity']['fields']['date_closed']['merge_filter']='disabled';

 

 // created: 2020-12-18 14:52:23
$dictionary['Opportunity']['fields']['opportunity_number_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['opportunity_number_c']['labelValue']='Opportunity Number';

 

 // created: 2020-03-24 18:53:05
$dictionary['Opportunity']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 

 // created: 2020-03-24 18:53:05
$dictionary['Opportunity']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 

 // created: 2020-12-03 14:45:40
$dictionary['Opportunity']['fields']['opp_quote_issuer_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['opp_quote_issuer_c']['labelValue']='Quote Issuer';

 

 // created: 2020-12-18 14:51:57
$dictionary['Opportunity']['fields']['sales_stage']['len']=100;
$dictionary['Opportunity']['fields']['sales_stage']['inline_edit']='';
$dictionary['Opportunity']['fields']['sales_stage']['comments']='Indication of progression towards closure';
$dictionary['Opportunity']['fields']['sales_stage']['merge_filter']='disabled';

 

 // created: 2020-12-12 11:52:58
$dictionary['Opportunity']['fields']['sales_order_nomber_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['sales_order_nomber_c']['labelValue']='Opportunities Order Nomber';

 

 // created: 2020-03-24 18:53:05
$dictionary['Opportunity']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 

 // created: 2020-12-18 14:52:52
$dictionary['Opportunity']['fields']['opportunity_key_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['opportunity_key_c']['labelValue']='Opportunity Key';

 

 // created: 2020-10-26 06:02:41
$dictionary['Opportunity']['fields']['opportunity_name_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['opportunity_name_c']['labelValue']='Opportunity Name';

 

 // created: 2020-10-27 19:47:21
$dictionary['Opportunity']['fields']['test1_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['test1_c']['labelValue']='test1';

 

 // created: 2020-03-24 18:53:05
$dictionary['Opportunity']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 
?>