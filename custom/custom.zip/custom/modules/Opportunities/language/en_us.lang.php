<?php
// created: 2020-12-18 14:51:57
$mod_strings = array (
  'LBL_DATE_CLOSED' => 'Expected Close Date:',
  'LBL_OPPORTUNITY_KEY' => 'Opportunity Key',
  'LBL_OPPORTUNITY_NUMBER' => 'Opportunity Number',
  'AOS_Quotes' => 'Quotes',
  'LBL_EDITVIEW_PANEL1' => 'New Panel 1',
  'LBL_OPP_QUOTE_ISSUER' => 'OQuote Issuer',
  'LBL_SALE_ORD_NO' => 'OSales Order Number',
  'LBL_SALES_STAGE' => 'Sales Stage:',
);