<?php
$popupMeta = array (
    'moduleMain' => 'Opportunity',
    'varName' => 'OPPORTUNITY',
    'orderBy' => 'name',
    'whereClauses' => array (
  'name' => 'opportunities.name',
  'account_name' => 'accounts.name',
  'sales_stage' => 'opportunities.sales_stage',
  'assigned_user_id' => 'opportunities.assigned_user_id',
  'opportunity_key_c' => 'opportunities_cstm.opportunity_key_c',
  'sales_order_nomber_c' => 'opportunities_cstm.sales_order_nomber_c',
),
    'searchInputs' => array (
  0 => 'name',
  1 => 'account_name',
  3 => 'sales_stage',
  4 => 'assigned_user_id',
  5 => 'opportunity_key_c',
  6 => 'sales_order_nomber_c',
),
    'searchdefs' => array (
  'opportunity_key_c' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_OPPORTUNITY_KEY',
    'width' => '10%',
    'name' => 'opportunity_key_c',
  ),
  'sales_order_nomber_c' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SALE_ORD_NO',
    'width' => '10%',
    'name' => 'sales_order_nomber_c',
  ),
  'name' => 
  array (
    'name' => 'name',
    'width' => '10%',
  ),
  'account_name' => 
  array (
    'name' => 'account_name',
    'displayParams' => 
    array (
      'hideButtons' => 'true',
      'size' => 30,
      'class' => 'sqsEnabled sqsNoAutofill',
    ),
    'width' => '10%',
  ),
  'sales_stage' => 
  array (
    'name' => 'sales_stage',
    'width' => '10%',
  ),
  'assigned_user_id' => 
  array (
    'name' => 'assigned_user_id',
    'type' => 'enum',
    'label' => 'LBL_ASSIGNED_TO',
    'function' => 
    array (
      'name' => 'get_user_array',
      'params' => 
      array (
        0 => false,
      ),
    ),
    'width' => '10%',
  ),
),
    'listviewdefs' => array (
  'OPPORTUNITY_KEY_C' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'label' => 'LBL_OPPORTUNITY_KEY',
    'width' => '5%',
    'name' => 'opportunity_key_c',
  ),
  'SALES_ORDER_NOMBER_C' => 
  array (
    'type' => 'varchar',
    'default' => true,
    'label' => 'LBL_SALE_ORD_NO',
    'width' => '5%',
    'name' => 'sales_order_nomber_c',
  ),
  'NAME' => 
  array (
    'width' => '40%',
    'label' => 'LBL_LIST_OPPORTUNITY_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'ACCOUNT_NAME' => 
  array (
    'width' => '30%',
    'label' => 'LBL_LIST_ACCOUNT_NAME',
    'id' => 'ACCOUNT_ID',
    'module' => 'Accounts',
    'default' => true,
    'sortable' => true,
    'ACLTag' => 'ACCOUNT',
    'name' => 'account_name',
  ),
  'SALES_STAGE' => 
  array (
    'width' => '10%',
    'label' => 'LBL_LIST_SALES_STAGE',
    'default' => true,
    'name' => 'sales_stage',
  ),
  'OPP_QUOTE_ISSUER_C' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_OPP_QUOTE_ISSUER',
    'width' => '10%',
    'name' => 'opp_quote_issuer_c',
  ),
),
);
