<?php
// created: 2021-07-09 20:51:01
$mod_strings = array (
	'LBL_POSITION' => 'Position'
);