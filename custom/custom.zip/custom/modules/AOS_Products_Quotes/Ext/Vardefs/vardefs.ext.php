<?php 
 //WARNING: The contents of this file are auto-generated


$dictionary['AOS_Products_Quotes']['fields']['tc_name'] = array(
    'inline_edit' => 1,
    'required' => true,
    'name' => 'tc_name',
    'vname' => 'TC Name',
    'type' => 'varchar',
    'massupdate' => '0',
    'default' => '',
    'no_default' => false,
    'comments' => NULL,
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => true,
    'reportable' => true,
    'unified_search' => false,
    'merge_filter' => 'disabled',
    'len' => '225',
    'size' => '20',
    'studio' => 'true',
);
$dictionary['AOS_Products_Quotes']['fields']['tc_description'] = array(
    'inline_edit' => 1,
    'required' => true,
    'name' => 'tc_description',
    'vname' => 'TC Description',
    'type' => 'text',
    'type' => 'text',
    'massupdate' => '0',
    'default' => '',
    'no_default' => false,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => false,
    'reportable' => true,
    'unified_search' => false,
    'merge_filter' => 'disabled',
    'size' => '20',
    'studio' => 'visible',
    'rows' => '6',
    'cols' => '80',	
);

 // created: 2021-07-09 20:51:01
$dictionary['AOS_Products_Quotes']['fields']['position_c']['inline_edit']='1';
$dictionary['AOS_Products_Quotes']['fields']['position_c']['labelValue']='position';

 
?>