<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2021-07-09 20:51:01
$mod_strings['LBL_POSITION'] = 'Position';
?>