<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2020-05-26 14:20:03
$dictionary["AOS_Products"]["fields"]["aos_products_contacts_1"] = array (
  'name' => 'aos_products_contacts_1',
  'type' => 'link',
  'relationship' => 'aos_products_contacts_1',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'side' => 'right',
  'vname' => 'LBL_AOS_PRODUCTS_CONTACTS_1_FROM_CONTACTS_TITLE',
);


// created: 2020-05-10 20:08:56
$dictionary["AOS_Products"]["fields"]["accounts_aos_products_1"] = array (
  'name' => 'accounts_aos_products_1',
  'type' => 'link',
  'relationship' => 'accounts_aos_products_1',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'vname' => 'LBL_ACCOUNTS_AOS_PRODUCTS_1_FROM_ACCOUNTS_TITLE',
  'id_name' => 'accounts_aos_products_1accounts_ida',
);
$dictionary["AOS_Products"]["fields"]["accounts_aos_products_1_name"] = array (
  'name' => 'accounts_aos_products_1_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ACCOUNTS_AOS_PRODUCTS_1_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'accounts_aos_products_1accounts_ida',
  'link' => 'accounts_aos_products_1',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
$dictionary["AOS_Products"]["fields"]["accounts_aos_products_1accounts_ida"] = array (
  'name' => 'accounts_aos_products_1accounts_ida',
  'type' => 'link',
  'relationship' => 'accounts_aos_products_1',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_ACCOUNTS_AOS_PRODUCTS_1_FROM_AOS_PRODUCTS_TITLE',
);


 // created: 2020-11-11 16:15:01
$dictionary['AOS_Products']['fields']['customs_code_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['customs_code_c']['labelValue']='HS Code';

 

 // created: 2020-11-11 16:17:18
$dictionary['AOS_Products']['fields']['type']['default']='';
$dictionary['AOS_Products']['fields']['type']['required']=true;

 

 // created: 2020-11-11 16:04:28
$dictionary['AOS_Products']['fields']['product_type_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['product_type_c']['labelValue']='product type';

 

 // created: 2020-10-27 18:12:05
$dictionary['AOS_Products']['fields']['machine_type_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['machine_type_c']['labelValue']='Machine Type';

 

 // created: 2020-11-11 15:40:42
$dictionary['AOS_Products']['fields']['product_type_master_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['product_type_master_c']['labelValue']='product type master';

 

 // created: 2020-11-11 16:08:29
$dictionary['AOS_Products']['fields']['product_subtype_c']['inline_edit']='1';
$dictionary['AOS_Products']['fields']['product_subtype_c']['labelValue']='Product Subtype';

 
?>