<?php 
 //WARNING: The contents of this file are auto-generated


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_ACCOUNTS_AOS_PRODUCTS_1_FROM_ACCOUNTS_TITLE'] = 'Accounts';


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_ACCOUNTS_AOS_PRODUCTS_1_FROM_ACCOUNTS_TITLE'] = 'Accounts';
$mod_strings['LBL_AOS_PRODUCTS_CONTACTS_1_FROM_CONTACTS_TITLE'] = 'Spisak Kupaca';

?>