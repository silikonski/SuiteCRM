<?php
// created: 2020-11-11 16:15:01
$mod_strings = array (
  'LBL_TYPE' => 'Product Type',
  'LBL_MACHINE_TYPE' => 'Machine Type',
  'LBL_PRODUCT_SUBTYPE' => 'Product Subtype',
  'LBL_CUSTOMS_CODE' => 'HS Code',
);