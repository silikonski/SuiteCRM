<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2020-11-12 10:41:35
$dictionary['AOS_Product_Categories']['fields']['abbreviation_c']['inline_edit']='1';
$dictionary['AOS_Product_Categories']['fields']['abbreviation_c']['labelValue']='Supplier Abbreviation';

 
?>