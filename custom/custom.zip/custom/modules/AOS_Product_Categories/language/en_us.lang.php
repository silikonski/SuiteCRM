<?php
// created: 2020-11-12 10:41:35
$mod_strings = array (
  'LBL_ABBREVIATION' => 'Supplier Abbreviation',
);